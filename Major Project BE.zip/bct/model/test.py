import speech_recognition as sr
from googletrans import Translator

# Create a speech recognizer
r = sr.Recognizer()

# Create a microphone object
mic = sr.Microphone()

# Define a function to convert speech to text


def speech_to_text(r, mic):
    with mic as source:
        audio = r.listen(source)

    try:
        text = r.recognize_google(audio)
        return text
    except sr.UnknownValueError:
        print("Could not understand audio")
        return None

# Define a function to translate text to Hindi


def translate_to_hindi(text):
    translator = Translator()
    translated_text = translator.translate(text, dest='hi')
    return translated_text.text


# Get the speech input from the user
speech_input = speech_to_text(r, mic)

# Translate the speech input to Hindi
hindi_translation = translate_to_hindi(speech_input)

# Print the translated text
print("The translated text is:", hindi_translation)
